# Changelog

## \[2.2.9]

### Dependencies

- Upgraded to `deep-link-js@2.4.6`

## \[2.2.8]

### Dependencies

- Upgraded to `deep-link-js@2.4.5`

## \[2.2.7]

### Dependencies

- Upgraded to `deep-link-js@2.4.4`

## \[2.2.6]

### Dependencies

- Upgraded to `deep-link-js@2.4.3`

## \[2.2.5]

### Dependencies

- Upgraded to `deep-link-js@2.4.2`

## \[2.2.4]

### Dependencies

- Upgraded to `deep-link-js@2.4.1`

## \[2.2.3]

### Dependencies

- Upgraded to `deep-link-js@2.4.0`

## \[2.2.2]

### Dependencies

- Upgraded to `deep-link-js@2.3.0`

## \[2.2.1]

### Dependencies

- Upgraded to `deep-link-js@2.2.1`

## \[2.2.0]

### Dependencies

- Upgraded to `deep-link-js@2.1.0`

## \[2.0.1]

### Dependencies

- Upgraded to `deep-link-js@2.0.1`

## \[2.0.0]

- [`e2c4dfb6`](https://github.com/tauri-apps/plugins-workspace/commit/e2c4dfb6af43e5dd8d9ceba232c315f5febd55c1) Update to tauri v2 stable release.

### Dependencies

- Upgraded to `deep-link-js@2.0.0`

## \[2.0.0-rc.1]

### Dependencies

- Upgraded to `deep-link-js@2.0.0-rc.2`

## \[2.0.0-rc.0]

### Dependencies

- Upgraded to `deep-link-js@2.0.0-rc.1`

## \[2.0.0-beta.11]

### Dependencies

- Upgraded to `deep-link-js@2.0.0-rc.0`

## \[2.0.0-beta.10]

### Dependencies

- Upgraded to `deep-link-js@2.0.0-beta.10`

## \[2.0.0-beta.9]

### Dependencies

- Upgraded to `deep-link-js@2.0.0-beta.9`

## \[2.0.0-beta.8]

### Dependencies

- Upgraded to `deep-link-js@2.0.0-beta.8`

## \[2.0.0-beta.7]

### Dependencies

- Upgraded to `deep-link-js@2.0.0-beta.7`

## \[2.0.0-beta.6]

### Dependencies

- Upgraded to `deep-link-js@2.0.0-beta.6`

## \[2.0.0-beta.5]

### Dependencies

- Upgraded to `deep-link-js@2.0.0-beta.5`

## \[2.0.0-beta.4]

### Dependencies

- Upgraded to `deep-link-js@2.0.0-beta.4`

## \[2.0.0-beta.3]

### Dependencies

- Upgraded to `deep-link-js@2.0.0-beta.3`

## \[2.0.0-beta.2]

### Dependencies

- Upgraded to `deep-link-js@2.0.0-beta.2`

## \[2.0.0-beta.1]

### Dependencies

- Upgraded to `deep-link-js@2.0.0-beta.1`

## \[2.0.0-beta.0]

### Dependencies

- Upgraded to `deep-link-js@2.0.0-beta.0`

## \[0.0.1-alpha.4]

### Dependencies

- Upgraded to `deep-link-js@2.0.0-alpha.4`

## \[0.0.1-alpha.3]

### Dependencies

- Upgraded to `deep-link-js@2.0.0-alpha.3`

## \[0.0.1-alpha.2]

### Dependencies

- Upgraded to `deep-link-js@2.0.0-alpha.2`

## \[0.0.1-alpha.1]

### Dependencies

- Upgraded to `deep-link-js@2.0.0-alpha.1`

## \[0.0.1-alpha.0]

### Dependencies

- Upgraded to `deep-link-js@2.0.0-alpha.0`
