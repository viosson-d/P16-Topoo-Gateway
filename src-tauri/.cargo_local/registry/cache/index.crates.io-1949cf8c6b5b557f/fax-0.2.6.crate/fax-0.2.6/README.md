# CCITT Group 3 and 4 image encodings.

Currently supported:
- de- and encoding group 4 images
- decoding group 3 images


You can ask questions on [Zulip](https://type.zulipchat.com/#narrow/stream/209232-pdf/topic/fax.20.2F.20master)
