# Math routines

Mostly fast and accurate math.

Most of the methods have ULP less than 0.5.
