---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: feature request
assignees: ''

---

If you like my work, please consider sponsoring me!

Please describe what you'd like to be added. For example:
 * Adding a new system support.
 * Getting new system information.
