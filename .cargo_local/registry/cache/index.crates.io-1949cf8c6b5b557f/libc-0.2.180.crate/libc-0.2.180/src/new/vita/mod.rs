//! VITASDK system library.
// FIXME(vita): link to headers or manpages needed.
