//! WASI libc.
//!
//! * Headers: <https://github.com/WebAssembly/wasi-libc>
