//! Trusty libc.
// FIXME(trusty): link to headers needed.
