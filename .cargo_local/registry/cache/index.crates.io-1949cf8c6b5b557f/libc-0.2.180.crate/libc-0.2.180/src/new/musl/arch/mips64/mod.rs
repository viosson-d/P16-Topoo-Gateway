//! Source directory: `arch/mips64/`
//!
//! <https://github.com/kraj/musl/tree/master/arch/mips64>

pub(crate) mod bits {
    pub(crate) mod socket;
}
