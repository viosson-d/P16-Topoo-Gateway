//! Interfaces common in NetBSD-derived operating systems. This includes NetBSD and OpenBSD.
