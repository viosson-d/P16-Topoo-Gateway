//! This directory maps to `include/uapi` in the Linux source tree.

pub(crate) mod linux;
