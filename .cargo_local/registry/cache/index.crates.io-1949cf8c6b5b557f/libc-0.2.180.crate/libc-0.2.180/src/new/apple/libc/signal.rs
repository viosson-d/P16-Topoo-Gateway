//! Header: `signal.h`
//!
//! <https://github.com/apple-oss-distributions/Libc/blob/main/include/signal.h>

pub use crate::sys::signal::*;
