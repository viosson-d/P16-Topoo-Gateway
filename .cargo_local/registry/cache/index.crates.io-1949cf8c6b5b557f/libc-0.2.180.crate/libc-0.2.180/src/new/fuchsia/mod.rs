//! Fuschia libc.
// FIXME(fuchsia): link to headers needed.

pub(crate) mod unistd;
