This is a list of contributors to the exrs project.

* [Johannes Vollmer](https://github.com/johannesvollmer)
* [Mandeep Bhutani](https://github.com/mandeep)
* [Daniel Santana](https://github.com/dgsantana)
* [Karel Peeters](https://github.com/KarelPeeters)
* [Dorian Fevrier](https://github.com/Narann)
* [Andrey Fedotov](https://github.com/anfedotoff)
* [Sergey "Shnatsel" Davidoff](https://github.com/Shnatsel)
* [Andrey Fedotov](https://github.com/anfedotoff)
* [Jonathan Behrens](https://github.com/fintelia)
* [Michael Ciraci](https://github.com/michaelciraci)
* [Oscar](https://github.com/okey)
* [Dongjia "toka" Zhang](https://github.com/tokatoka)
* [Marijn Suijten](https://github.com/MarijnS95)

Thank you for your time and efforts that you spent to improve the exrs project!
