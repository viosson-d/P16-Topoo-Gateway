## Zune core

Core primitives necessary for image manipulations

This crate contains small set of primitives
necessary for image manipulations which are shared among most   `zune-` family
of decoders and encoders.

### Items present

Currently,it contains.

- Colorspace definitions
- Bit depth definitions.
- Decoder and encoder options